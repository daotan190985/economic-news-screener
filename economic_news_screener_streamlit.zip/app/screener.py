import pandas as pd
import numpy as np
from sqlalchemy.orm import Session
from .models import Financial, Dividend

def _rolling_volatility(close: pd.Series, window: int = 20):
    return close.pct_change().rolling(window).std()

def screen_fundamental(session: Session, thresholds: dict):
    q = session.query(Financial)
    rows = pd.read_sql(q.statement, session.bind)
    if rows.empty:
        return pd.DataFrame(columns=["symbol", "reason"])
    latest = rows.sort_values(["symbol", "period"]).groupby("symbol").tail(1)

    cond = (
        (latest["roe"] >= thresholds.get("min_roe", 0)) &
        (latest["roc"] >= thresholds.get("min_roc", 0)) &
        (latest["gpm"] >= thresholds.get("min_gpm", 0)) &
        (latest["de_ratio"] <= thresholds.get("max_de_ratio", 9e9))
    )
    selected = latest.loc[cond, ["symbol"]].copy()
    selected["reason"] = "Fundamentals met"
    return selected

def screen_technical(prices: pd.DataFrame, cfg: dict):
    if prices.empty:
        return pd.DataFrame(columns=["symbol", "reason"])

    out = []
    prices = prices.dropna(subset=["close"]).copy()
    for sym, g in prices.sort_values("date").groupby("symbol"):
        g = g.copy()
        g["ma_fast"] = g["close"].rolling(cfg.get("ma_fast", 10)).mean()
        g["ma_slow"] = g["close"].rolling(cfg.get("ma_slow", 20)).mean()
        g["vol20"] = _rolling_volatility(g["close"], cfg.get("vol_contraction_window", 20))
        g["vol60"] = _rolling_volatility(g["close"], 60)
        g["dd60"] = g["close"] / g["close"].rolling(60).max() - 1.0
        g["liq20"] = g["volume"].rolling(20).mean()
        if len(g) < 60:
            continue
        last = g.iloc[-1]

        ok_liq = (last["liq20"] or 0) >= cfg.get("min_liquidity_avg_20d", 0)
        ok_dd = abs(last["dd60"] or 0) >= cfg.get("max_drawdown_60d", 0)
        ok_base = (last["ma_fast"] or 0) >= (last["ma_slow"] or 0)
        ref = g["vol60"].iloc[-60:-20].mean() if len(g) >= 80 else (last["vol60"] or 0)
        vol_contract = (last["vol20"] or 0) <= (1 - cfg.get("vol_contraction_pct", 0.3)) * (ref or 1e-9)

        if ok_liq and ok_dd and ok_base and vol_contract:
            out.append({"symbol": sym, "reason": "Pullback+Base+Vol contraction"})
    return pd.DataFrame(out)

def merge_with_dividends(session: Session, picks: pd.DataFrame):
    if picks.empty:
        return picks
    q = session.query(Dividend)
    dv = pd.read_sql(q.statement, session.bind)
    if dv.empty:
        picks["upcoming_dividend"] = False
        return picks
    dv = dv.dropna(subset=["ex_date"]).copy()
    now = pd.Timestamp.utcnow()
    soon = now + pd.Timedelta(days=45)
    mark = dv[(dv["ex_date"] >= now) & (dv["ex_date"] <= soon)]
    picks["upcoming_dividend"] = picks["symbol"].isin(mark["symbol"].unique())
    return picks
