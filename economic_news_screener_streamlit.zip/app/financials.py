import pandas as pd
from pathlib import Path
from sqlalchemy.orm import Session
from .models import Financial

def load_financials_from_folder(session: Session, folder: str = "data/financials"):
    path = Path(folder)
    path.mkdir(parents=True, exist_ok=True)
    files = list(path.glob("*.csv")) + list(path.glob("*.xlsx"))
    count = 0
    for f in files:
        if f.suffix.lower() == ".csv":
            df = pd.read_csv(f)
        else:
            df = pd.read_excel(f)
        df = df.fillna({"roe": None, "roc": None, "gpm": None, "de_ratio": None})
        for _, r in df.iterrows():
            obj = Financial(
                symbol=str(r["symbol"]).upper(),
                period=str(r["period"]),
                roe=float(r.get("roe", 0) or 0),
                roc=float(r.get("roc", 0) or 0),
                gpm=float(r.get("gpm", 0) or 0),
                de_ratio=float(r.get("de_ratio", 0) or 0),
                revenue=float(r.get("revenue", 0) or 0),
                net_income=float(r.get("net_income", 0) or 0),
            )
            session.add(obj)
            count += 1
    session.commit()
    return count
