import feedparser
from dateutil import parser as dtp
from sqlalchemy.orm import Session
from .models import News

def parse_dt(x):
    try:
        return dtp.parse(x)
    except Exception:
        return None

def ingest_rss(session: Session, sources: list[dict]):
    inserted = 0
    for s in sources:
        if s.get("type") != "rss":
            continue
        feed = feedparser.parse(s["url"])
        for e in feed.entries:
            link = e.get("link")
            if not link:
                continue
            if session.query(News).filter_by(link=link).first():
                continue
            n = News(
                source=s["name"],
                title=e.get("title", ""),
                link=link,
                published_at=parse_dt(e.get("published") or e.get("updated") or ""),
                summary=e.get("summary"),
            )
            session.add(n)
            inserted += 1
    session.commit()
    return inserted
