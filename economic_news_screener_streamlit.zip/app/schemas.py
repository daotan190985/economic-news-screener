from pydantic import BaseModel
from datetime import datetime

class NewsOut(BaseModel):
    source: str
    title: str
    link: str
    published_at: datetime | None
    summary: str | None

class ScreenResult(BaseModel):
    symbol: str
    reason: str
