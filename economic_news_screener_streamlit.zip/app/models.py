from sqlalchemy import Column, Integer, String, DateTime, Text, Float, Boolean, UniqueConstraint
from sqlalchemy.sql import func
from .db import Base

class News(Base):
    __tablename__ = "news"
    id = Column(Integer, primary_key=True)
    source = Column(String(120))
    title = Column(String(500))
    link = Column(String(1000), unique=True)
    published_at = Column(DateTime)
    summary = Column(Text)
    created_at = Column(DateTime, server_default=func.now())

class Ticker(Base):
    __tablename__ = "tickers"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), unique=True, index=True)
    exchange = Column(String(20), default="VN")
    sector = Column(String(120))
    is_active = Column(Boolean, default=True)

class Financial(Base):
    __tablename__ = "financials"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), index=True)
    period = Column(String(20))
    roe = Column(Float)
    roc = Column(Float)
    gpm = Column(Float)
    de_ratio = Column(Float)
    revenue = Column(Float)
    net_income = Column(Float)
    UniqueConstraint("symbol", "period", name="uq_financial_symbol_period")

class Dividend(Base):
    __tablename__ = "dividends"
    id = Column(Integer, primary_key=True)
    symbol = Column(String(20), index=True)
    ex_date = Column(DateTime)
    pay_date = Column(DateTime)
    amount = Column(Float)
    currency = Column(String(10), default="VND")
