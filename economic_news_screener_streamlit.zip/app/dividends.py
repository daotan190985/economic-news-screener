import pandas as pd
from dateutil import parser as dtp
from sqlalchemy.orm import Session
from .models import Dividend

def upsert_dividends_from_csv(session: Session, csv_path: str = "data/dividend_calendar.csv"):
    try:
        df = pd.read_csv(csv_path)
    except FileNotFoundError:
        return 0
    df = df.fillna({"currency": "VND"})
    count = 0
    for _, r in df.iterrows():
        d = Dividend(
            symbol=str(r["symbol"]).upper(),
            ex_date=dtp.parse(str(r["ex_date"])) if r.get("ex_date") else None,
            pay_date=dtp.parse(str(r["pay_date"])) if r.get("pay_date") else None,
            amount=float(r.get("amount", 0) or 0),
            currency=str(r.get("currency", "VND")),
        )
        session.add(d)
        count += 1
    session.commit()
    return count
