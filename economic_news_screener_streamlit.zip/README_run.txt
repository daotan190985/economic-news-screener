Economic News & Stock Screener (VN) – Streamlit Cloud
=====================================================

Tính năng
- Tổng hợp tin kinh tế từ báo chính thống (RSS).
- Nạp báo cáo tài chính mẫu, lịch chia cổ tức mẫu.
- Sàng lọc cổ phiếu: cơ bản + kỹ thuật (pullback & tích lũy).
- Mở được trên điện thoại qua link streamlit.app.

Cách chạy LOCAL (tuỳ chọn)
--------------------------
python -m venv .venv
. .venv/Scripts/activate  (Windows)
pip install -r requirements.txt
streamlit run streamlit_app.py

Lưu ý
-----
Kết quả sàng lọc chỉ nhằm mục đích THAM KHẢO, không phải khuyến nghị đầu tư.
